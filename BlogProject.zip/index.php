<?php include('header/header.php'); ?>
    
    
    <?php include('navbar/nav.php'); ?>
    
    <!-- End Navbar -->
    
   
        <div class="jumbotron">
             <div class="container-fluid">
                 <div class="row">
                     <div class="col-lg-8">
                         <h1>Blog Project</h1>
                         <p class="lead">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Cursus in hac habitasse platea dictumst quisque sagittis. Nascetur ridiculus mus mauris vitae ultricies leo integer malesuada nunc. Eget arcu dictum varius duis at consectetur. Duis at consectetur lorem donec massa sapien. Quam id leo in vitae turpis. Adipiscing vitae proin sagittis nisl rhoncus mattis rhoncus urna neque. Suspendisse faucibus interdum posuere lorem ipsum. Quis lectus nulla at volutpat diam ut venenatis tellus in. Nunc mattis enim ut tellus elementum sagittis. Nisi porta lorem mollis aliquam ut. Vestibulum mattis ullamcorper velit sed. Viverra nibh cras pulvinar mattis nunc sed blandit.</p>
                     </div>
                     
                     <div class="col-lg-4">
                         <img src="https://dummyimage.com/600x400/000/fff.png" class="img-fluid" alt="">
                     </div>
                 </div>
             </div>  
        </div>
        <!-- End Jumbotron -->
        
        <div class="main">
            <div class="container-fluid">
                <div class="row">
                    
                    <?php include('Main/main.php'); ?>
                    <!-- Start Sidebar -->
                    
                    <div class="col-lg-4">
                         <?php include('Sidebar/sidebar.php'); ?>
                    </div><!-- End Sidebar -->
                    
                    <div class="col-lg-12">
                          <?php include('Pagination/pagination.php'); ?>
                    </div><!-- End pagination -->
                    
                    
                </div><!-- End Row -->
            </div><!-- End Container fluid -->
            
        </div><!-- End Main -->
        
       <?php include('footer/footer.php'); ?>