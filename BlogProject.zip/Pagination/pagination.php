<ul class="pagination">
    <li class="page-item"><a href="" class="page-link">Older</a></li>
    <li class="page-item"><a href="" class="page-link">New</a></li>
</ul>