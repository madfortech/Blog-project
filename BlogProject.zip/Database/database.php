<?php

$localhost = 'localhost';
$username = 'root';
$password = '';
$databaseName = 'blogProject';

$secureConnection = mysqli_connect($localhost,$username,$password,$databaseName);

if(!$secureConnection){
   echo "CONNECTION LOST"; 
}


?>