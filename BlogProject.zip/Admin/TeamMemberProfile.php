<div class="card TeamMemberProfile">
    <h2>CREATE TEAM MEMBER PROFILE</h2>
    <form action="">
        <div class="form-group">
            <label for="">Team Member Name</label>
            <input type="text" class="form-control" placeholder="Team Member Name">
        </div>

        <div class="form-group">
            <label for="">Team Member Profile Pic</label>
            <input type="file" class="form-control">
        </div>

        <div class="form-group">
            <label for="">Team Member Work Profile</label>
            <input type="text" class="form-control" placeholder="Team Member Work Profile">
        </div>

        <button type="submit" class="btn btn-primary">ADD Team</button>
    </form>
</div><!-- End Team Member Profile -->