 <div class="card addTags">
     <h2>Add Tags</h2>
     <form action="">
         <div class="form-group">
             <label for="">Add your tags</label>
             <input type="text" class="form-control" placeholder="ADD YOUR TAG">
         </div>

         <button type="submit" class="btn btn-primary">ADD TAG</button>
     </form>
 </div><!-- End card -->