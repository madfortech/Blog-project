<?php include('header/header.php'); ?>
 
<?php include('Navbar/nav.php'); ?> 

 <div class="main">
     <div class="container-fluid">
         <div class="row">

             <div class="col-lg-12">
                 <?php include('Main/main.php'); ?> 
             </div><!-- End  -->


         </div><!-- End Row -->
     </div><!-- End Container fluid -->

 </div><!-- End Main -->


<!-- <?php include('footer/footer.php'); ?>-->
 
