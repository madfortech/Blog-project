 <div class="card addLink">
     <h2>Add Link</h2>
     <form action="">
         <div class="form-group">
             <label for="">Add your link</label>
             <input type="text" class="form-control" placeholder="ADD YOUR LINKS">
         </div>

         <button type="submit" class="btn btn-primary">ADD Links</button>
     </form>
 </div><!-- End add links -->