 
        <footer>
            <div class="container-fluid">
                <div class="col-lg-12">
                    <p class="text-center">&copy; 2019</p>
                </div>
            </div>
        </footer>
            
                
                        
    <script src="js/bootstrap.js"></script>
</body>
</html>