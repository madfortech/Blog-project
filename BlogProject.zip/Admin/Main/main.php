 <div class="main">
     <div class="container-fluid">
         <div class="row">

             <div class="col-lg-2 card text-center">
                 <?php include('userProfile.php'); ?>
             </div><!-- End user profile -->

             <div class="col-lg-8">
                 <div class="card deletePost">
                     <h2>Some demo content</h2>
                 </div>
             </div><!-- End user post -->

             <div class="col-lg-2">
                 <?php include('addTags.php'); ?>
             </div>

         </div><!-- End row -->


         <div class="row">
             <div class="col-lg-8">
                 <?php include('addPost.php'); ?>
             </div><!-- End   Post  -->

             <div class="col-lg-2">
                 <?php include('addLink.php'); ?>
             </div>

             <div class="col-lg-2">
                 <?php include('TeamMemberProfile.php'); ?>

             </div>

         </div><!-- End row -->


     </div><!-- End Container fluid -->

 </div><!-- End Main -->