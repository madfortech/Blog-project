<div class="userProfile">
    <img src="https://dummyimage.com/150x150/000/fff" class="rounded-circle" alt="">
    <div class="card-text">
        <p class=""><strong>Himanshu nishad</strong></p>
    </div>
</div>