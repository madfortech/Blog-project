<div class="card addPost">
    <h2>CREATE NEW POST</h2>
    <form action="">
        <div class="form-group">
            <label for="">Add your title</label>
            <input type="text" class="form-control" placeholder="ADD YOUR TITLE">
        </div>

        <div class="form-group">
            <label for="">Add your image</label>
            <input type="file" class="form-control">
        </div>

        <div class="form-group">
            <label for="">Add your content</label>
            <textarea name="" id="" cols="30" rows="10" class="form-control" placeholder="ADD YOUR CONTENT"></textarea>
        </div>

        <button type="submit" class="btn btn-primary">ADD POST</button>
    </form>
</div> <!-- End addpost -->