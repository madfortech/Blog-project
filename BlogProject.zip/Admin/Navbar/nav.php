<nav class="navbar navbar-expand bg-dark">

    <a href="" class="navbar-brand">Admin Area</a>

    <ul class="navbar-nav ml-auto">
        <li class="nav-item"><a href="" class="nav-link"><ion-icon size="large" name="notifications-outline"></ion-icon></a></li>
        <li class="nav-item"><a href="" class="nav-link"><ion-icon size="large" name="log-out"></ion-icon></a></li>
      
    </ul>
</nav>