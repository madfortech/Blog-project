<nav class="navbar navbar-expand bg-dark">

    <a href="" class="navbar-brand">Logo</a>

    <ul class="navbar-nav ml-auto">
        <li class="nav-item"><a href="" class="nav-link">Home</a></li>
        <li class="nav-item"><a href="" class="nav-link">About</a></li>
        <li class="nav-item"><a href="" class="nav-link">Service</a></li>
        <li class="nav-item"><a href="" class="nav-link">Contact</a></li>
        <li class="nav-item"><a href="createPage.php" class="nav-link">create a page</a></li>
    </ul>
    
   
</nav>