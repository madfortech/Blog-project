
 
 <h3 class="display-4">Recent Post</h3>
 <div class="media">
     <img src="https://dummyimage.com/100x100/000/fff" class="rounded" alt="">
     <div class="media-body">
         <?php
         
         $RecentQuery = "SELECT * FROM blogpost";
         $RecentResult = mysqli_query($secureConnection,$RecentQuery);
         
         while($row = mysqli_fetch_array($RecentResult)){
             
             $BlogHeading = $row['BlogHeading'];
             $PostContent = $row['PostContent'];
             
            
         
            echo  "<h4>$BlogHeading</h4>"; 
            echo   "<p>$PostContent</p>"; 
         
         ?>
         
       <?php } ?>

         
     </div>
 </div>

 <hr>

