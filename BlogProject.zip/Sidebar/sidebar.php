<div class="About">
     <?php include('about.php'); ?>
</div><!-- End About -->

<hr>

<div class="recentPost">
   <?php include('recentPost.php'); ?>
</div><!-- End recentPost -->