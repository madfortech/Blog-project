<div class="col-lg-8">
    <?php include('post.php'); ?>

</div>