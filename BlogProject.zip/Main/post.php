<div class="card">
    <div class="card-body">
       
       <?php
         
         $PostQuery = "SELECT * FROM blogpost";
         $PostResult = mysqli_query($secureConnection,$PostQuery);
         
         while($row = mysqli_fetch_array($PostResult)){
             
             $BlogHeading = $row['BlogHeading'];
             $PostContent = $row['PostContent'];
             
            
         
            
            echo  "<div class='card-title'> <h2>$BlogHeading</h2></div>"; 
            echo "<div class='card-img'><img src='https://dummyimage.com/600x250/000/fff' class='img-fluid' alt=''></div>";
            echo "<div class='card-text'>$PostContent</div>"; 
            echo "<div class='card-link'><a href='' class='btn btn-primary'>Readmore</a></div>"; 
             
         
         ?>

       <?php } ?>
       
       

    </div>
</div><!-- End Card -->

